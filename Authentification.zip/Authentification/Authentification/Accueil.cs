﻿/*
 * Crée par SharpDevelop.
 * Utilisateur: miros
 * Date: 19/05/2023
 * Heure: 11:59
 * 
 * Pour changer ce modèle utiliser Outils | Options | Codage | Editer les en-têtes standards.
 */
using System;
using System.Drawing;
using System.Windows.Forms;

namespace Authentification
{
	/// <summary>
	/// Description of Accueil.
	/// </summary>
	public partial class Accueil : Form
	{
		public Accueil()
		{
			//
			// The InitializeComponent() call is required for Windows Forms designer support.
			//
			InitializeComponent();
			
			//
			// TODO: Add constructor code after the InitializeComponent() call.
			//
		}
	}
}
