﻿/*
 * Crée par SharpDevelop.
 * Utilisateur: miros
 * Date: 19/05/2023
 * Heure: 10:59
 * 
 * Pour changer ce modèle utiliser Outils | Options | Codage | Editer les en-têtes standards.
 */
namespace Authentification
{
	partial class MainForm
	{
		/// <summary>
		/// Designer variable used to keep track of non-visual components.
		/// </summary>
		private System.ComponentModel.IContainer components = null;
		private System.Windows.Forms.TextBox textBox1;
		private System.Windows.Forms.TextBox textBox2;
		private System.Windows.Forms.Button btnAuthentification;
		private System.Windows.Forms.Button btnAccount;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Label label2;
		
		/// <summary>
		/// Disposes resources used by the form.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing) {
				if (components != null) {
					components.Dispose();
				}
			}
			base.Dispose(disposing);
		}
		
		/// <summary>
		/// This method is required for Windows Forms designer support.
		/// Do not change the method contents inside the source code editor. The Forms designer might
		/// not be able to load this method if it was changed manually.
		/// </summary>
		private void InitializeComponent()
		{
			this.textBox1 = new System.Windows.Forms.TextBox();
			this.textBox2 = new System.Windows.Forms.TextBox();
			this.btnAuthentification = new System.Windows.Forms.Button();
			this.btnAccount = new System.Windows.Forms.Button();
			this.label1 = new System.Windows.Forms.Label();
			this.label2 = new System.Windows.Forms.Label();
			this.SuspendLayout();
			// 
			// textBox1
			// 
			this.textBox1.Location = new System.Drawing.Point(94, 141);
			this.textBox1.Name = "textBox1";
			this.textBox1.Size = new System.Drawing.Size(100, 20);
			this.textBox1.TabIndex = 0;
			// 
			// textBox2
			// 
			this.textBox2.Location = new System.Drawing.Point(94, 198);
			this.textBox2.Name = "textBox2";
			this.textBox2.Size = new System.Drawing.Size(100, 20);
			this.textBox2.TabIndex = 1;
			// 
			// btnAuthentification
			// 
			this.btnAuthentification.Location = new System.Drawing.Point(94, 258);
			this.btnAuthentification.Name = "btnAuthentification";
			this.btnAuthentification.Size = new System.Drawing.Size(100, 23);
			this.btnAuthentification.TabIndex = 2;
			this.btnAuthentification.Text = "Authentification";
			this.btnAuthentification.UseVisualStyleBackColor = true;
			this.btnAuthentification.Click += new System.EventHandler(this.BtnAuthentificationClick);
			// 
			// btnAccount
			// 
			this.btnAccount.Location = new System.Drawing.Point(94, 299);
			this.btnAccount.Name = "btnAccount";
			this.btnAccount.Size = new System.Drawing.Size(100, 23);
			this.btnAccount.TabIndex = 3;
			this.btnAccount.Text = "New Account";
			this.btnAccount.UseVisualStyleBackColor = true;
			this.btnAccount.Click += new System.EventHandler(this.BtnAccountClick);
			// 
			// label1
			// 
			this.label1.Location = new System.Drawing.Point(94, 112);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(100, 23);
			this.label1.TabIndex = 4;
			this.label1.Text = "login";
			// 
			// label2
			// 
			this.label2.Location = new System.Drawing.Point(94, 169);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(100, 23);
			this.label2.TabIndex = 5;
			this.label2.Text = "mdp";
			// 
			// MainForm
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(281, 446);
			this.Controls.Add(this.label2);
			this.Controls.Add(this.label1);
			this.Controls.Add(this.btnAccount);
			this.Controls.Add(this.btnAuthentification);
			this.Controls.Add(this.textBox2);
			this.Controls.Add(this.textBox1);
			this.Name = "MainForm";
			this.Text = "Authentification";
			this.ResumeLayout(false);
			this.PerformLayout();

		}
	}
}
