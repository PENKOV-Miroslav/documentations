﻿/*
 * Created by SharpDevelop.
 * User: miros
 * Date: 18/05/2023
 * Time: 12:58
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;
using System.Collections.Generic;
using System.Data;
using System.Windows.Forms;

namespace AppCRUD
{
	/// <summary>
	/// Description of MainForm.
	/// </summary>
	public partial class MainForm : Form
	{
		public MainForm()
		{
			//
			// The InitializeComponent() call is required for Windows Forms designer support.
			//
			InitializeComponent();
			
			//
			// TODO: Add constructor code after the InitializeComponent() call.
			//
		}
		
		Utilisateur util = new Utilisateur();
		
		
		void BtnInsertionClick(object sender, EventArgs e)
		{
			    if (dataGridView1.Rows.Count > 0)
			    {
			        foreach (DataGridViewRow row in dataGridView1.Rows)
			        {
			        	string nouveauId =  row.Cells[0].Value.ToString();
			        	int convNouveauId = int.Parse(nouveauId);
			            string nouveauNom = row.Cells[1].Value.ToString(); // Récupérer la valeur du nom depuis la première cellule
			            string nouveauPrenom = row.Cells[2].Value.ToString(); // Récupérer la valeur du prénom depuis la deuxième cellule
			
			            // Vérifier si les valeurs ne sont pas vides ou null
			            if (!string.IsNullOrEmpty(nouveauNom) && !string.IsNullOrEmpty(nouveauPrenom))
			            {
			                // Créer un nouvel objet utilisateur avec les nouvelles valeurs
			                Utilisateur nouvelUtilisateur = new Utilisateur();
			                nouvelUtilisateur.setidUtilisateur(convNouveauId);
			                nouvelUtilisateur.setnom(nouveauNom);
			                nouvelUtilisateur.setprenom(nouveauPrenom);
			
			                BDD.connexion();
			                nouvelUtilisateur.insertUtilisateur();
			
			                MessageBox.Show("Insertion effectuée", "Valide", MessageBoxButtons.OK);
			            }
			            else
			            {
			                MessageBox.Show("Valeur de cellule non valide.", "Erreur d'insertion", MessageBoxButtons.OK, MessageBoxIcon.Error);
			            }
			        }
			    }
			    else
			    {
			        MessageBox.Show("Aucune donnée à insérer.", "Erreur d'insertion", MessageBoxButtons.OK, MessageBoxIcon.Error);
			    }
	
		}
		
		
		void BtnSelectionClick(object sender, EventArgs e)
		{
		
		    util.setidUtilisateur(int.Parse(textBox1.Text));
		
		    DataTable dataTable = util.selectUtilisateur();
		    dataGridView1.DataSource = dataTable;
		    textBox1.Text=String.Empty; //Efface le contenu des textBox

	
		}
		
		
		void BtnUpdateClick(object sender, EventArgs e)
		{
				    if (dataGridView1.SelectedRows.Count > 0)
				    {
				        foreach (DataGridViewRow row in dataGridView1.SelectedRows)
				        {
				            int idUtilisateur;
				            if (int.TryParse(row.Cells[0].Value.ToString(), out idUtilisateur))
				            {
				                string nouveauNom = row.Cells[1].Value.ToString(); // Récupérer la nouvelle valeur du nom depuis la deuxième cellule
				                string nouveauPrenom = row.Cells[2].Value.ToString(); // Récupérer la nouvelle valeur du prénom depuis la troisième cellule
				                
				                util.setidUtilisateur(idUtilisateur);
				                util.setnom(nouveauNom);
				                util.setprenom(nouveauPrenom);
				                
				                BDD.connexion();
				                util.updateUtilisateur();
				                
				                MessageBox.Show("Mise à jour effectuée", "Valide", MessageBoxButtons.OK);
				            }
				            else
				            {
				                MessageBox.Show("ID utilisateur non valide.", "Erreur de conversion", MessageBoxButtons.OK, MessageBoxIcon.Error);
				            }
				        }
				    }
				    else
				    {
				        MessageBox.Show("Aucune ligne sélectionnée.", "Erreur de sélection", MessageBoxButtons.OK, MessageBoxIcon.Error);
				    }
		}

		
		
		void BtnDeleteClick(object sender, EventArgs e)
		{
			if (dataGridView1.SelectedRows.Count > 0)
			    {
			        string dataSuppr = dataGridView1.SelectedRows[0].Cells[0].Value.ToString();
			        int number;
			        if (int.TryParse(dataSuppr, out number))
			        {
			            util.setidUtilisateur(number);
			            BDD.connexion();
			            util.deleteUtilisateur();
			            MessageBox.Show("suppression effectuer","appuiez sur ok", MessageBoxButtons.OK);
			        }
			        else
			        {
			            // Gérer le cas où la conversion échoue
			            MessageBox.Show("Valeur de cellule non valide.", "Erreur de conversion", MessageBoxButtons.OK, MessageBoxIcon.Error);
			        }
			    }
			    else
			    {
			        // Gérer le cas où aucune ligne n'est sélectionnée
			        MessageBox.Show("Aucune ligne sélectionnée.", "Erreur de sélection", MessageBoxButtons.OK, MessageBoxIcon.Error);
			    }

	
		}
		
		
		void BtnFindAllClick(object sender, EventArgs e)
		{
			
			/*//premier moyen pour avoir un findAll
			dataGridView1.Rows.Clear();
			Utilisateur utilisateurRepository = new Utilisateur();
			List<Utilisateur> utilisateurs = utilisateurRepository.FindAllUtilisateur();
			foreach (Utilisateur utilisateur in utilisateurs)
			{
			    dataGridView1.Rows.Add(utilisateur.getidUtilisateur(), utilisateur.getnom(), utilisateur.getprenom());
			}*/
			
			//second myen d'avoir un findAll qui soit plus simple a maintenir		
		    DataTable dataTable = util.FindAllTestUtilisateur();
		    dataGridView1.DataSource = dataTable;
			

		}

	}
}
